document.write(
    "<iframe width=\"242\" height=\"50\" style=\"border:0;width:242px;height:50px;overflow:hidden;background-color:transparent;\" allowTransparency=\"true\" src=\"\"></iframe>"
);